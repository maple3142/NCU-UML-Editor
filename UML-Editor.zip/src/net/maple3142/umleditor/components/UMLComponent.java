package net.maple3142.umleditor.components;

import java.awt.Graphics;

public interface UMLComponent {
    void draw(Graphics g);
}
