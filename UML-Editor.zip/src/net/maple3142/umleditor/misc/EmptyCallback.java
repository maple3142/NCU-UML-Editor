package net.maple3142.umleditor.misc;

@FunctionalInterface
public interface EmptyCallback {
    void call();
}
