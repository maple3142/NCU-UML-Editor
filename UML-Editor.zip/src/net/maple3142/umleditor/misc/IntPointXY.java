package net.maple3142.umleditor.misc;

public interface IntPointXY {
    int getX();

    int getY();
}
